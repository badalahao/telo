Script Instalasi OpenVPN + MySQL Auth
=====================================

Dependencies :

- mysql-client openvpn easy-rsa php5-cli

Tested On :

- Debian 7
- Debian 8
- Ubuntu 14.04
- Ubuntu 16.04

Created By :

- Bahirul Rizki A <rizki.device@gmail.com>
