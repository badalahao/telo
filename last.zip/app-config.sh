#!/bin/bash

#OpenVPN Config
OVPN_IP=$(curl ipinfo.io/ip)
OVPN_COUNTRY='SG'
OVPN_PROVINCE='SG'
OVPN_CITY='SG'
OVPN_ORG='White-VPS'
OVPN_MAIL='admin@white-vps.com'
OVPN_CERT='ovpn-server'
OVPN_PORTS=''

#MySQL Remote Host
MYSQL_HOST='128.199.255.230'
MYSQL_PORT='3306'
MYSQL_DB='askarali_whitevp1_whitevps2'
MYSQL_USER='askarali_root'
MYSQL_PASS='randy27bast'
