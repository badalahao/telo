#!/bin/bash

. ./app-config.sh

#Welcome Banner
echo "================== Script Auto Install OpenVPN + MySQL Custom ... ===================="
echo "======================================================================================"

echo "......................................................................................"
echo "......................................................................................"

echo "======================================================================================"
echo "======================================================================================"

echo -en "\n\n"


#Install Dependencies

echo "========================== Memasang applikasi pendukung ... =========================="
echo "======================================================================================"

apt-get update
apt-get -f install -y
apt-get install mysql-client openvpn php5-cli -y

if [ -d generated/easy-rsa ]; then
	rm -rf generated/easy-rsa
fi

if [ -d /usr/share/doc/openvpn/examples/easy-rsa/2.0 ];
	then
	cp -r /usr/share/doc/openvpn/examples/easy-rsa/2.0 generated/easy-rsa
else
	apt-get install easy-rsa -y
	make-cadir generated/easy-rsa
fi



echo "======================================================================================"
echo "======================================================================================"

echo -en "\n\n"

#Generate Files
echo "========================== Inisialisasi file ... ====================================="
echo "======================================================================================"

echo "......................................................................................"
echo "......................................................................................"


rm -rf generated/scripts/*
rm -rf generated/ovpn/client/*
rm -rf generated/ovpn/server/*

cp templates/scripts/connected.sh generated/scripts/
cp templates/scripts/disconnected.sh generated/scripts/
cp templates/scripts/config.sh generated/scripts/
cp templates/scripts/login.sh generated/scripts/

echo "......................................................................................"
echo "......................................................................................"

echo "======================================================================================"
echo "======================================================================================"

echo -en "\n\n"

echo "......................................................................................"
echo "......................................................................................"


#OpenVPN Mysql
sed -i -e s/ovpn_ip/"$OVPN_IP"/g generated/scripts/connected.sh
sed -i -e s/ovpn_ip/"$OVPN_IP"/g generated/scripts/disconnected.sh

sed -i -e s/mysql_host/"$MYSQL_HOST"/g generated/scripts/config.sh

sed -i -e s/mysql_port/"$MYSQL_PORT"/g generated/scripts/config.sh

sed -i -e s/mysql_db/"$MYSQL_DB"/g generated/scripts/config.sh

sed -i -e s/mysql_user/"$MYSQL_USER"/g generated/scripts/config.sh

sed -i -e s/mysql_pass/"$MYSQL_PASS"/g generated/scripts/config.sh

echo "======================================================================================"
echo "======================================================================================"

echo -en "\n\n"

#OpenVPN Detail
echo "========================== Inisialisasi OpenVPN Key ... ================================"
echo "======================================================================================"

echo "......................................................................................"
echo "......................................................................................"


echo "======================================================================================"
echo "======================================================================================"

echo -en "\n\n"


#Generate Easy-RSA

echo "========================== Menghasilkan File Easy-RSA ... ============================"
echo "======================================================================================"

sed -i -e 's/KEY_COUNTRY="US"/KEY_COUNTRY="'$OVPN_COUNTRY'"/g' generated/easy-rsa/vars
sed -i -e 's/KEY_PROVINCE="CA"/KEY_PROVINCE="'$OVPN_PROVINCE'"/g' generated/easy-rsa/vars
sed -i -e 's/KEY_CITY="SanFrancisco"/KEY_CITY="'$OVPN_CITY'"/g' generated/easy-rsa/vars
sed -i -e 's/KEY_ORG="Fort-Funston"/KEY_ORG="'$OVPN_ORG'"/g' generated/easy-rsa/vars
sed -i -e 's/KEY_EMAIL="me@myhost.mydomain"/KEY_EMAIL="'$OVPN_MAIL'"/g' generated/easy-rsa/vars
sed -i -e 's/KEY_OU="MyOrganizationalUnit"/KEY_OU="'$OVPN_ORG'"/g' generated/easy-rsa/vars
sed -i -e 's/KEY_NAME="EasyRSA"/KEY_NAME="'$OVPN_CERT'"/g' generated/easy-rsa/vars

if [ -d /usr/share/doc/openvpn/examples/easy-rsa/2.0 ];
	then
		sed -i -e 's/KEY_EMAIL=mail@host.domain/KEY_EMAIL='$OVPN_MAIL'/g' generated/easy-rsa/vars
		sed -i -e 's/KEY_OU=changeme/KEY_OU='$OVPN_ORG'/g' generated/easy-rsa/vars
		sed -i -e 's/KEY_NAME=changeme/KEY_OU='$OVPN_CERT'/g' generated/easy-rsa/vars
		sed -i -e 's/KEY_CN=changeme/KEY_OU='$OVPN_ORG'/g' generated/easy-rsa/vars
		sed -i -e 's/KEY_SIZE=1024/KEY_SIZE=2048/g' generated/easy-rsa/vars
fi

cd generated/easy-rsa
source vars
./clean-all
./build-ca --batch
./build-dh --batch
./build-key-server --batch $OVPN_CERT
cd ../ && cd ../

echo "======================================================================================"
echo "======================================================================================"

echo -en "\n\n"

echo "======================= Menghasilkan File OpenVPN Server ... ========================="
echo "======================================================================================"

IFS=',' read -ra ovpn_array_ports <<< "$OVPN_PORTS"

ovpn_32_ips=101;

for ovpn_port in "${ovpn_array_ports[@]}"
do
	ip=$((ovpn_32_ips++))

	tcp_ip="10.17.$ip.0"
	udp_ip="10.18.$ip.0"

	echo "Menghasilkan konfigurasi OpenVPN server port ${ovpn_port} TCP dan UDP ..."

	cp templates/ovpn/server/TCP.conf generated/ovpn/server/TCP-"${ovpn_port}".conf
	cp templates/ovpn/server/UDP.conf generated/ovpn/server/UDP-"${ovpn_port}".conf

	sed -i -e 's/ovpn_name/'$OVPN_CERT'/g' generated/ovpn/server/TCP-${ovpn_port}.conf
	sed -i -e 's/ovpn_name/'$OVPN_CERT'/g' generated/ovpn/server/UDP-${ovpn_port}.conf
	sed -i -e 's/ovpn_port/'$ovpn_port'/g' generated/ovpn/server/TCP-${ovpn_port}.conf
	sed -i -e 's/ovpn_port/'$ovpn_port'/g' generated/ovpn/server/UDP-${ovpn_port}.conf
	sed -i -e 's/ovpn_ip/'$tcp_ip'/g' generated/ovpn/server/TCP-${ovpn_port}.conf
	sed -i -e 's/ovpn_ip/'$udp_ip'/g' generated/ovpn/server/UDP-${ovpn_port}.conf

done

echo "======================================================================================="
echo "======================================================================================="

echo -en "\n\n"

echo "======================== Menghasilkan File OpenVPN Client ... ========================="
echo "======================================================================================="

ca=$( cat generated/easy-rsa/keys/ca.crt )

for ovpn_port in "${ovpn_array_ports[@]}"
do	

echo "Menghasilkan konfigurasi OpenVPN client port ${ovpn_port} TCP dan UDP ..."

cp templates/ovpn/client/TCP.ovpn generated/ovpn/client/TCP-"${ovpn_port}".ovpn
cp templates/ovpn/client/UDP.ovpn generated/ovpn/client/UDP-"${ovpn_port}".ovpn

sed -i -e 's/ovpn_ip/'$OVPN_IP'/g'  generated/ovpn/client/TCP-${ovpn_port}.ovpn
sed -i -e 's/ovpn_ip/'$OVPN_IP'/g'  generated/ovpn/client/UDP-${ovpn_port}.ovpn
sed -i -e 's/ovpn_port/'$ovpn_port'/g'  generated/ovpn/client/TCP-${ovpn_port}.ovpn
sed -i -e 's/ovpn_port/'$ovpn_port'/g'  generated/ovpn/client/UDP-${ovpn_port}.ovpn

php templates/ovpn/ca-gen.php

done

echo "========================================================================================"
echo "========================================================================================"

echo -en "\n\n"

echo "============================== Mengatur Firewall NAT ... ==============================="
echo "========================================================================================"

echo "Mengatur ulang Firewall ..."

iptables -X
iptables -F
iptables -X -t nat
iptables -F -t nat

iptables -A POSTROUTING -t nat -s 10.0.0.0/8 -o eth0 -j MASQUERADE

echo "Simpan rule firewall ...."

iptables-save > /etc/iptables-ovpn.conf

sed -i '/# rc.local/a iptables-restore < /etc/iptables-ovpn.conf' /etc/rc.local

echo "Pengaturan firewall selesai ..."

echo "======================================================================================="
echo "======================================================================================="

echo -en "\n\n"

echo "========================= Pengaturan Akhir Server OpenVPN ... ========================="
echo "======================================================================================="

echo "......................................................................................"
echo "......................................................................................"

folder_client=$(pwd)/generated/ovpn/client

mkdir -p /etc/openvpn/logs
cp -r generated/easy-rsa/keys /etc/openvpn/
cp -r generated/scripts /etc/openvpn/
cp -r generated/ovpn/server/* /etc/openvpn/

sysctl -p /etc/sysctl.conf

if [ -d /run/systemd/system ]; then

	systemctl daemon-reload

fi

/etc/init.d/openvpn restart



echo "File OpenVPN client bisa dilihat di folder $folder_client"

echo "......................................................................................"
echo "......................................................................................"

echo "======================================================================================="
echo "======================================================================================="

echo -en "\n\n"

echo "========================= Pengaturan selesai ... ======================================"
echo "======================================================================================="

echo "......................................................................................"
echo "......................................................................................"

echo "Silahkan restart / reboot server ....."

echo "......................................................................................"
echo "......................................................................................"


echo "======================================================================================="
echo "======================================================================================="

echo -en "\n\n"