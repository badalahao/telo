<?php

$read_all_ca = scandir('./generated/ovpn/client/');
$fixed_ca = array_diff($read_all_ca, array('..', '.','.gitkeep'));
$fixed_ca = array_values($fixed_ca);

$ca_crt = rtrim(file_get_contents('./generated/easy-rsa/keys/ca.crt'));


for($i=0;$i < sizeOf($fixed_ca);$i++){
	$old_config = file_get_contents('./generated/ovpn/client/' . $fixed_ca[$i]);
	$new_config = str_replace('ovpn_ca', $ca_crt, $old_config);
	file_put_contents('./generated/ovpn/client/' . $fixed_ca[$i], $new_config);
}

$ovpn_start = file_get_contents("/etc/default/openvpn");
$new_ovpn_start = str_replace('#AUTOSTART="all"', 'AUTOSTART="all"', $ovpn_start);
file_put_contents("/etc/default/openvpn", $new_ovpn_start);


$sysctl_old = file_get_contents("/etc/sysctl.conf");
$sysctl_new = str_replace('#net.ipv4.ip_forward=1', 'net.ipv4.ip_forward=1', $sysctl_old);
file_put_contents("/etc/sysctl.conf", $sysctl_new);