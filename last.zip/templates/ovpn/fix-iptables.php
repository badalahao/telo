<?php

$rc_local = file_get_contents('/etc/rc.local');

$fix_iptable_restore = preg_replace('#iptables-restore > /etc/iptables-ovpn.conf#', 'iptables-restore < /etc/iptables-ovpn.conf', $rc_local);

file_put_contents('/etc/rc.local', $fix_iptable_restore);

echo "iptables restore fixed ... \n";