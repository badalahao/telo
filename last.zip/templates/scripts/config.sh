#!/bin/bash
##Dababase Server
HOST='mysql_host'
#Default port = 3306
PORT='mysql_port'
#Username
USER='mysql_user'
#Password
PASS='mysql_pass'
#database name
DB='mysql_db'
