#!/bin/bash
. /etc/openvpn/scripts/config.sh

##se status online to user connected
mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -e "UPDATE session_account SET status=1 WHERE username='$username' AND ip_address='ovpn_ip'"
