#!/bin/bash
. /etc/openvpn/scripts/config.sh

##set status online to user connected
mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -e "UPDATE session_account SET status=0 WHERE username='$username' AND ip_address='ovpn_ip'"
