#!/bin/bash
. /etc/openvpn/scripts/config.sh

##Test Authentication
user_id=$(mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -sN -e "select username from account where username = '$username' AND password = '$password' AND CURDATE() <= expired_date")

##Check user
[ "$user_id" != '' ] && [ "$user_id" = "$username" ] && echo "user : $username" && echo 'authentication ok.' && exit 0 || echo 'authentication failed.'; exit 1
